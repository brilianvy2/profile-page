// JavaScript code
document.querySelector('.button').addEventListener('click', function() {
    alert('Button clicked!');
});
